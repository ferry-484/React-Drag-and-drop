import "./App.css";
import Routes from "./Routes";

function App() {
  return (
    <div className="App">
      <br />
      <br />
      <Routes />
    </div>
  );
}

export default App;
