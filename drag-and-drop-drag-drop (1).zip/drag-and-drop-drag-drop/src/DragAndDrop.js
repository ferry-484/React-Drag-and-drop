import React, { useMemo, useState } from 'react'
import { useDropzone } from 'react-dropzone'
import CloudUploadIcon from '@material-ui/icons/CloudUpload'
import Button from '@material-ui/core/Button'
import Checkbox from '@material-ui/core/Checkbox'
import FormGroup from '@material-ui/core/FormGroup'
import FormControlLabel from '@material-ui/core/FormControlLabel'
import axios from 'axios'
import { apiURL } from './apiURL'
import CircularProgress from '@material-ui/core/CircularProgress'

const baseStyle = {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: '30px',
    borderWidth: 3,
    borderRadius: 3,
    fontSize: '18px',
    borderColor: '#eeeeee',
    borderStyle: 'dashed',
    backgroundColor: '#fafafa',
    color: '#a2a2a2',
    outline: 'none',
    transition: 'border .24s ease-in-out'
};
  
const activeStyle = {
    borderColor: '#2196f3'
};

const acceptStyle = {
    borderColor: '#00e676'
};

const rejectStyle = {
    borderColor: '#ff1744'
};

function DragAndDrop() {
    const setDefaultTypes = () => {
        return [
            {checked: false, type: '.jpg'},
            {checked: false, type: '.jpeg'},
            {checked: false, type: '.png'},
            {checked: false, type: '.pdf'},
            {checked: false, type: '.gif'},
            {checked: false, type: '.svg'},
            {checked: false, type: '.mp4'},
            {checked: false, type: '.mp3'}
        ];
    }
    const [fileTypes, setFileTypes] = useState(setDefaultTypes);
    const [draggedFiles, setDraggedFiles] = useState([]);
    const [progress, setProgress] = useState(false);
    const {
        getRootProps,
        getInputProps,
        open,
        isDragActive,
        isDragAccept,
        isDragReject,
        acceptedFiles
    } = useDropzone({
        accept: fileTypes.filter(type => type.checked).length ? fileTypes.filter(type => type.checked).map(type => {return type.type}) : '', 
        noClick: true, 
        noKeyboard: true,
        onDrop: (acceptedFiles) => {
            setDraggedFiles(acceptedFiles.map(file => Object.assign(file, {
                preview: URL.createObjectURL(file)
            })));
        },
        onDropRejected: (fileRejections) => {
            if(fileRejections.length) {
                alert('Some files are not acceptable.')
            }
        }
    });

    let files = acceptedFiles.map(file => 
        <li key={file.path}>
            {file.path} - {file.type} - {file.size} bytes
        </li>
    );
    
    const style = useMemo(() => ({
        ...baseStyle,
        ...(isDragActive ? activeStyle : {}),
        ...(isDragAccept ? acceptStyle : {}),
        ...(isDragReject ? rejectStyle : {})
    }), [
        isDragActive,
        isDragReject,
        isDragAccept
    ]);
    
    const getFileTypes = (checked, id) => {
        let arr = fileTypes;
        arr[id].checked = checked;
        setFileTypes([...arr]);
    }

    const uploadFiles = () => {
        let formData = new FormData();
        setProgress(true);
        draggedFiles.forEach(file => {
            formData.append('files', file);
        })
        axios.post(apiURL + '/upload', formData)
        .then(res => {
            console.log(res);
            if(res['data'].status === 200) {
                setProgress(false);
                alert('Files uploaded succesfully!');
            }
        })
        .catch(err => {
            setProgress(false);
            console.log(err);
        })
    }

    const resetFilters = () => {
        setFileTypes(setDefaultTypes);
    }

    return (
        <div className="container">
            <div {...getRootProps({style})}>
                <input {...getInputProps()} />
                <p>Drag and drop some files here...</p>
                <Button
                    variant="contained"
                    color="secondary"
                    onClick={() => open()}
                >
                    Choose
                </Button>
            </div>
            <FormGroup row>
                {fileTypes.map((type, index) => {
                    return(
                        <FormControlLabel key = {index}
                            control={
                                <Checkbox
                                    checked={type.checked}
                                    color="secondary"
                                    onChange={(evt) => getFileTypes(evt.target.checked, index)}
                                    value={type.type}
                                />
                            }
                            label={type.type}
                        />
                    )
                })}
            <Button 
                variant="outlined" 
                color="secondary"
                style={{marginLeft: 'auto'}} 
                onClick={() => resetFilters()}
            >
                Reset
            </Button>
            </FormGroup>
            <ul style={{listStyle: 'none'}}>{files}</ul>
            {progress ? <CircularProgress variant="indeterminate"/> : null}
            <Button 
                onClick={() => uploadFiles()} 
                variant="contained" 
                color="secondary" 
                disabled={acceptedFiles.length === 0} 
                startIcon={<CloudUploadIcon />}
            >
                Upload
            </Button>
        </div>
    );
}

export default DragAndDrop
