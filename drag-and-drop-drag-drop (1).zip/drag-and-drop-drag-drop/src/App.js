import './App.css';
import DragAndDrop from './DragAndDrop';

function App() {
  return (
    <div className="App">
      <DragAndDrop />
    </div>
  );
}

export default App;
